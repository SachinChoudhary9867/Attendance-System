document.addEventListener('DOMContentLoaded', function() {
    // Fetch stats for the chart
    fetch('/api/stats')
        .then(response => response.json())
        .then(data => {
            if (data.error) return;

            renderChart(data);
            renderGuidance(data);
        });
});

function renderChart(data) {
    const ctx = document.getElementById('subjectChart');
    if (!ctx) return;

    const labels = data.map(s => s.subject);
    const percentages = data.map(s => (s.attended / s.total) * 100);

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Attendance %',
                data: percentages,
                backgroundColor: percentages.map(p => p < 75 ? 'rgba(239, 68, 68, 0.6)' : 'rgba(16, 185, 129, 0.6)'),
                borderColor: percentages.map(p => p < 75 ? 'rgb(239, 68, 68)' : 'rgb(16, 185, 129)'),
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

function renderGuidance(data) {
    const container = document.getElementById('guidance-container');
    if (!container) return;

    let html = '';
    data.forEach(s => {
        const percentage = (s.attended / s.total) * 100;
        if (percentage < 75) {
            // Formula: (attended + x) / (total + x) = 0.75
            // attended + x = 0.75 * total + 0.75 * x
            // 0.25 * x = 0.75 * total - attended
            // x = (0.75 * total - attended) / 0.25
            const required = Math.ceil((0.75 * s.total - s.attended) / 0.25);
            
            html += `
                <div class="guidance-card">
                    <p><strong>${s.subject}:</strong> You need to attend <strong>${required > 0 ? required : 0}</strong> more lectures to reach 75%.</p>
                </div>
            `;
        } else {
            html += `
                <div class="guidance-card" style="background: #f0fdf4; border-color: #dcfce7;">
                    <p><strong>${s.subject}:</strong> Your attendance is safe! Keep it up.</p>
                </div>
            `;
        }
    });

    if (html === '') {
        html = '<p>No attendance data available yet.</p>';
    }

    container.innerHTML = html;
}
