from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'secret_key_for_session'

# Database setup
DATABASE = 'attendance.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        # Students table
        conn.execute('''
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                roll_no TEXT UNIQUE NOT NULL,
                department TEXT NOT NULL,
                semester TEXT NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        # Faculty table
        conn.execute('''
            CREATE TABLE IF NOT EXISTS faculty (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                department TEXT NOT NULL,
                subject TEXT NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        # Attendance table
        conn.execute('''
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                subject TEXT NOT NULL,
                date TEXT NOT NULL,
                status TEXT NOT NULL,
                FOREIGN KEY (student_id) REFERENCES students(id)
            )
        ''')
        conn.commit()

# Initialize the database
if not os.path.exists(DATABASE):
    init_db()

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        role = request.form.get('role')
        identifier = request.form.get('identifier')
        password = request.form.get('password')

        with get_db() as conn:
            if role == 'student':
                user = conn.execute('SELECT * FROM students WHERE roll_no = ? AND password = ?', (identifier, password)).fetchone()
                if user:
                    session['user_id'] = user['id']
                    session['role'] = 'student'
                    session['name'] = user['name']
                    return redirect(url_for('dashboard'))
            elif role == 'faculty':
                user = conn.execute('SELECT * FROM faculty WHERE name = ? AND password = ?', (identifier, password)).fetchone()
                if user:
                    session['user_id'] = user['id']
                    session['role'] = 'faculty'
                    session['name'] = user['name']
                    session['dept'] = user['department']
                    session['subject'] = user['subject']
                    return redirect(url_for('faculty_dashboard'))
            elif role == 'admin':
                if identifier == 'admin' and password == 'admin123':
                    session['user_id'] = 0
                    session['role'] = 'admin'
                    session['name'] = 'Admin'
                    return redirect(url_for('admin'))
        
        return render_template('index.html', error="Invalid username or password")
    
    return redirect(url_for('index'))

@app.route('/faculty_login')
def faculty_login():
    return redirect(url_for('index'))

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        action = request.form.get('action')
        with get_db() as conn:
            if action == 'register_student':
                name = request.form.get('name')
                roll_no = request.form.get('roll_no')
                dept = request.form.get('department')
                sem = request.form.get('semester')
                pwd = request.form.get('password')
                conn.execute('INSERT INTO students (name, roll_no, department, semester, password) VALUES (?, ?, ?, ?, ?)',
                             (name, roll_no, dept, sem, pwd))
            elif action == 'register_faculty':
                name = request.form.get('name')
                dept = request.form.get('department')
                subj = request.form.get('subject')
                pwd = request.form.get('password')
                conn.execute('INSERT INTO faculty (name, department, subject, password) VALUES (?, ?, ?, ?)',
                             (name, dept, subj, pwd))
            conn.commit()
        return redirect(url_for('admin'))

    with get_db() as conn:
        students = conn.execute('SELECT * FROM students').fetchall()
        faculty = conn.execute('SELECT * FROM faculty').fetchall()
    
    return render_template('admin.html', students=students, faculty=faculty)

@app.route('/faculty_dashboard', methods=['GET', 'POST'])
def faculty_dashboard():
    if session.get('role') != 'faculty':
        return redirect(url_for('login'))
    
    dept = session.get('dept')
    subject = session.get('subject')

    if request.method == 'POST':
        date = request.form.get('date')
        with get_db() as conn:
            students = conn.execute('SELECT id FROM students WHERE department = ?', (dept,)).fetchall()
            for student in students:
                status = request.form.get(f'status_{student["id"]}')
                if status:
                    conn.execute('INSERT INTO attendance (student_id, subject, date, status) VALUES (?, ?, ?, ?)',
                                 (student['id'], subject, date, status))
            conn.commit()
        return redirect(url_for('faculty_dashboard'))

    with get_db() as conn:
        students = conn.execute('SELECT * FROM students WHERE department = ?', (dept,)).fetchall()
    
    return render_template('faculty_dashboard.html', students=students, subject=subject)

@app.route('/dashboard')
def dashboard():
    if session.get('role') != 'student':
        return redirect(url_for('login'))
    
    student_id = session.get('user_id')
    with get_db() as conn:
        # Get subject-wise stats
        stats = conn.execute('''
            SELECT subject, 
                   COUNT(CASE WHEN status = 'Present' THEN 1 END) as attended,
                   COUNT(*) as total
            FROM attendance
            WHERE student_id = ?
            GROUP BY subject
        ''', (student_id,)).fetchall()
        
        # Get history
        history = conn.execute('''
            SELECT * FROM attendance WHERE student_id = ? ORDER BY date DESC
        ''', (student_id,)).fetchall()

    # Calculate overall
    total_attended = sum(s['attended'] for s in stats)
    total_lectures = sum(s['total'] for s in stats)
    overall_percentage = (total_attended / total_lectures * 100) if total_lectures > 0 else 0

    return render_template('dashboard.html', stats=stats, history=history, overall=overall_percentage, total_attended=total_attended, total_lectures=total_lectures)

@app.route('/api/stats')
def api_stats():
    if session.get('role') != 'student':
        return jsonify({'error': 'Unauthorized'}), 401
    
    student_id = session.get('user_id')
    with get_db() as conn:
        stats = conn.execute('''
            SELECT subject, 
                   COUNT(CASE WHEN status = 'Present' THEN 1 END) as attended,
                   COUNT(*) as total
            FROM attendance
            WHERE student_id = ?
            GROUP BY subject
        ''', (student_id,)).fetchall()
    
    return jsonify([dict(s) for s in stats])

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    print("Starting SAMAS Server...")
    # Cloud Run / AI Studio requires port 3000
    app.run(host='0.0.0.0', port=3000, debug=True)
