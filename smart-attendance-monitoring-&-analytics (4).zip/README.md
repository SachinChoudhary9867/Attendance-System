# Smart Student Attendance Monitoring and Analytics System

A complete full-stack web application built with Python Flask, SQLite, and Chart.js.

## Tech Stack
- **Frontend:** HTML, CSS, JavaScript, Chart.js
- **Backend:** Python Flask
- **Database:** SQLite

## Project Structure
```
attendance-system/
│
├── app.py              # Main Flask application logic
├── database.db         # SQLite database file (auto-generated)
│
├── templates/          # HTML templates
│   ├── index.html
│   ├── admin.html
│   ├── faculty_login.html
│   ├── faculty_dashboard.html
│   ├── login.html
│   ├── dashboard.html
│
├── static/             # Static assets
│   ├── style.css       # Custom styling
│   ├── script.js       # Chart.js and analytics logic
```

## Features
1. **Admin Panel:** Register students and faculty members.
2. **Faculty System:** Login, view students of their department, and mark attendance.
3. **Student System:** Login, view subject-wise attendance, overall percentage, and history.
4. **Analytics:** Visual representation of attendance using Chart.js.
5. **Guidance:** Automatic calculation of required lectures to reach 75% attendance.

## How to Run the Project Locally

### 1. Install Python
Ensure you have Python 3 installed on your system. You can download it from [python.org](https://python.org).

### 2. Install Flask
Open your terminal or command prompt and run:
```bash
pip install flask
```

### 3. Start the Server
Navigate to the project directory and run:
```bash
python app.py
```

### 4. Access the App
Open your web browser and go to:
`http://localhost:3000` (or `http://localhost:5000` depending on your configuration)

## Demo Credentials
- **Admin:** `admin` / `admin123`
- **Faculty:** (Register via Admin first)
- **Student:** (Register via Admin first)
